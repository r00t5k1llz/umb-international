<?php

$config = array(
    'dsn'     	=>'mysql',
    'host'    	=>'localhost',
    'dbname'    =>'bank',
    'username'  =>'jeanlinux',
    'password'  =>'j5an1inux'
);