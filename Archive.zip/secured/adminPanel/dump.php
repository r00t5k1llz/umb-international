<?php

$pass = 1;
$salt = '334343';
echo sha1($pass);