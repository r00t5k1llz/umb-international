<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Wikishore
 * Date: 9/2/13
 * Time: 9:07 AM
 * To change this template use File | Settings | File Templates.
 */

echo "Barclays Bank UAE";