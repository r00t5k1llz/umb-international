<?php
	header('refresh: 145; url=success.php?success=yes&transfercode=^Ec1rlXt2(_8wU34mgFVe5x4rjR!T#');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link href="css4/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css"/>
<link href="css4/main.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="js4/jquery-1.6.2.min.js"></script>
<script type="text/javascript" src="js4/jquery-ui-1.8.16.custom.min.js"></script> 
<script type="text/javascript" src="js4/script.js"></script>

<title>Transfering Amount</title>
</head>
<body>
    <div class="example">
        <h3>Transfer in Progress...</a></h3>
		<p>Please do not refresh your page. Your Code has been verified</p>

        <div id="progress1">
            <div class="percent"></div>
            <div class="pbar"></div>
            <!--<div class="elapsed"></div>-->
        </div>
    </div>
</body>
</html>