<?php

echo sha1('@u10enticYES');